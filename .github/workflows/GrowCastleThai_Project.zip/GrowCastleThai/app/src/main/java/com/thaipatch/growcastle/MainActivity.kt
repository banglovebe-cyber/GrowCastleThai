package com.thaipatch.growcastle

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.TextView
import android.widget.Toast
import android.widget.ImageView
import android.view.View
import rikka.shizuku.Shizuku
import java.io.File
import java.util.zip.ZipInputStream

class MainActivity : Activity() {

    private val gamePkg = "com.raongames.growcastle"
    private val shizukuPkg = "moe.shizuku.privileged.api"
    private val reqCode = 1001

    private lateinit var tvStatus: TextView
    private lateinit var tvLog: TextView
    private lateinit var ivStatus: ImageView
    private lateinit var btnInstall: View
    private lateinit var btnLaunch: View
    private val ui = Handler(Looper.getMainLooper())
    @Volatile private var busy = false

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        runOnUiThread {
            refresh()
            if (result == PackageManager.PERMISSION_GRANTED) startInstall()
        }
    }
    private val binderListener = Shizuku.OnBinderReceivedListener { runOnUiThread { refresh() } }
    private val deadListener = Shizuku.OnBinderDeadListener { runOnUiThread { refresh() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvStatus = findViewById(R.id.tvStatus)
        tvLog = findViewById(R.id.tvLog)
        ivStatus = findViewById(R.id.ivStatus)
        btnInstall = findViewById(R.id.btnInstall)
        btnLaunch = findViewById(R.id.btnLaunch)

        Shizuku.addRequestPermissionResultListener(permListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)

        btnInstall.setOnClickListener { onInstallClick() }
        btnLaunch.setOnClickListener { launchGame() }
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        super.onDestroy()
    }

    private fun shizukuReady() = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
    private fun shizukuGranted() = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    private fun refresh() {
        when {
            !shizukuReady() -> {
                tvStatus.text = "Shizuku ยังไม่ทำงาน (เปิดแอป Shizuku แล้วกดเริ่มทำงาน)"
                ivStatus.setImageResource(R.drawable.ic_alert)
            }
            !shizukuGranted() -> {
                tvStatus.text = "Shizuku พร้อมแล้ว รอการอนุญาตสิทธิ์"
                ivStatus.setImageResource(R.drawable.ic_alert)
            }
            else -> {
                tvStatus.text = "Shizuku พร้อมใช้งาน"
                ivStatus.setImageResource(R.drawable.ic_check)
            }
        }
    }

    private fun log(msg: String) = runOnUiThread { tvLog.text = msg }

    private fun onInstallClick() {
        if (busy) return
        if (!shizukuReady()) {
            Toast.makeText(this, "กรุณาเปิดและเริ่มทำงาน Shizuku ก่อน", Toast.LENGTH_LONG).show()
            packageManager.getLaunchIntentForPackage(shizukuPkg)?.let { startActivity(it) }
            return
        }
        if (!shizukuGranted()) {
            Shizuku.requestPermission(reqCode)
            return
        }
        startInstall()
    }

    private fun startInstall() {
        if (busy) return
        busy = true
        Thread {
            try {
                log("กำลังแตกไฟล์...")
                val stage = File(getExternalFilesDir(null), "stage")
                stage.deleteRecursively()
                stage.mkdirs()
                extractAsset("th.zip", stage)

                log("กำลังติดตั้งลงเกม...")
                val target = "/sdcard/Android/data/$gamePkg/files"
                val src = stage.absolutePath
                val cmd = "mkdir -p '$target' && " +
                    "rm -rf '$target/ServerTranslations' '$target/UserTranslations' && " +
                    "cp -rf '$src/ServerTranslations' '$src/UserTranslations' '$target/' && echo OK"
                val (code, out) = runShell(cmd)
                stage.deleteRecursively()
                if (code == 0 && out.contains("OK")) {
                    log("ติดตั้งสำเร็จ กำลังเปิดเกม...")
                    ui.postDelayed({ launchGame() }, 1000)
                } else {
                    log("ติดตั้งไม่สำเร็จ ($code)\n$out")
                }
            } catch (e: Throwable) {
                log("เกิดข้อผิดพลาด: ${e.message}")
            } finally {
                busy = false
            }
        }.start()
    }

    private fun extractAsset(name: String, dest: File) {
        val root = dest.canonicalPath
        ZipInputStream(assets.open(name)).use { zin ->
            var e = zin.nextEntry
            while (e != null) {
                val f = File(dest, e.name)
                if (!f.canonicalPath.startsWith(root)) throw SecurityException("bad entry")
                if (e.isDirectory) f.mkdirs() else {
                    f.parentFile?.mkdirs()
                    f.outputStream().use { zin.copyTo(it) }
                }
                zin.closeEntry()
                e = zin.nextEntry
            }
        }
    }

    private fun runShell(cmd: String): Pair<Int, String> {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        val err = p.errorStream.bufferedReader().readText()
        val code = p.waitFor()
        return code to (out + err).trim()
    }

    private fun launchGame() {
        val i: Intent? = packageManager.getLaunchIntentForPackage(gamePkg)
        if (i == null) {
            Toast.makeText(this, "ไม่พบเกม Grow Castle ในเครื่อง", Toast.LENGTH_LONG).show()
        } else {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        }
    }
}
