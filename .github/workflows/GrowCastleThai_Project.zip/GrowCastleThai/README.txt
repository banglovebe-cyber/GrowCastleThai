วิธีได้ไฟล์ APK (ไม่ต้องใช้คอม)
1. เข้า github.com สร้าง Repository ใหม่
2. อัปโหลดไฟล์ทั้งหมดในโฟลเดอร์นี้ (รวมโฟลเดอร์ .github) ขึ้นไป
3. เข้าแท็บ Actions รอ Build APK เสร็จ (ประมาณ 3-5 นาที)
4. เปิดรอบที่สำเร็จ ดาวน์โหลด GrowCastleThai-APK แล้วแตก zip จะได้ app-debug.apk

วิธีใช้
1. ติดตั้งแอป Shizuku แล้วเริ่มทำงาน (ผ่าน Wireless debugging)
2. เปิดแอปนี้ กด "ติดตั้งภาษาไทย" แล้วอนุญาตสิทธิ์ Shizuku
3. แอปจะลบ ServerTranslations/UserTranslations เดิม วางไฟล์ใหม่ทับ แล้วเปิดเกมให้อัตโนมัติ
